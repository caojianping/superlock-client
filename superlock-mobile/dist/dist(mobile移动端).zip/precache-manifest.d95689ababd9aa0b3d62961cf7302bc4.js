self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f368046ed1b601b9c889",
    "url": "css/app.e403a307.css"
  },
  {
    "revision": "405228a87a6f5029b8d3",
    "url": "css/chunk-vendors.2b1b1736.css"
  },
  {
    "revision": "ab05cf71c362372dfe3d3819eeaff6ab",
    "url": "img/asset-bg.ab05cf71.png"
  },
  {
    "revision": "1a71193a5145e5e8c0b9e39814756400",
    "url": "img/avatar.1a71193a.png"
  },
  {
    "revision": "d4863c29aa53b6c4e938211bcc6186bd",
    "url": "img/bnsc-bg.d4863c29.png"
  },
  {
    "revision": "4cc622b0cd359e60329e40cebf10fe4a",
    "url": "img/cylinder.4cc622b0.png"
  },
  {
    "revision": "598f6fb3f45d5a2b5b2511a65f719952",
    "url": "img/failure.598f6fb3.png"
  },
  {
    "revision": "5f307403b5e925bc47b0af078aa5235e",
    "url": "img/feature01.5f307403.png"
  },
  {
    "revision": "bf2ae90026fe21ff8ea595c98cf01080",
    "url": "img/feature02.bf2ae900.png"
  },
  {
    "revision": "32584fda47ebf86a8c74f460b823cbb8",
    "url": "img/feature03.32584fda.png"
  },
  {
    "revision": "96ddb02ad11cb4199545e4d963c53aa4",
    "url": "img/feature04.96ddb02a.png"
  },
  {
    "revision": "fe0f1ec16277fda00ee8f42466b0ff76",
    "url": "img/home-bg.fe0f1ec1.png"
  },
  {
    "revision": "f66a12ecdab196f3142e34c2cc068835",
    "url": "img/ljcj-bg.f66a12ec.png"
  },
  {
    "revision": "f762d688de9b03cd248df1f01116d4f1",
    "url": "img/ljzc-bg.f762d688.png"
  },
  {
    "revision": "e96e4ee1d66b75ea799684017d88174b",
    "url": "img/logo-lg.e96e4ee1.png"
  },
  {
    "revision": "0183d8b83869896894800911b964bfd1",
    "url": "img/prompt.0183d8b8.png"
  },
  {
    "revision": "4e42fc57cbf88eb0e9c5082a4f19d974",
    "url": "img/recharge.4e42fc57.png"
  },
  {
    "revision": "f87871ea69765eb6670ef65ebde9f982",
    "url": "img/rule-title.f87871ea.png"
  },
  {
    "revision": "1e8a17cd10f2b367127527247213fea9",
    "url": "img/rule01.1e8a17cd.png"
  },
  {
    "revision": "e0f752a536cfa98b0b80fba817b869ce",
    "url": "img/rule02.e0f752a5.png"
  },
  {
    "revision": "bdf3f0e5c1632c8f189eed0953981cc2",
    "url": "img/success.bdf3f0e5.png"
  },
  {
    "revision": "8d9fa04e9bb6ba5a66c20444199ddb4f",
    "url": "img/top01.8d9fa04e.png"
  },
  {
    "revision": "b5651f3e1bf2659aa4a6cb646a3ba1e5",
    "url": "img/top02.b5651f3e.png"
  },
  {
    "revision": "5f5a0c8810067daa94dfae5e72f49254",
    "url": "img/transfer.5f5a0c88.png"
  },
  {
    "revision": "ed42f04fdf97be05c0416d8c47c4c6b5",
    "url": "img/unopen.ed42f04f.png"
  },
  {
    "revision": "f4b9bbcd845b4d7ef1b41c123508548b",
    "url": "img/withdraw.f4b9bbcd.png"
  },
  {
    "revision": "6bbe292aca340196bc2bd7500b4ef01a",
    "url": "img/ynsc-bg.6bbe292a.png"
  },
  {
    "revision": "41e3e24d33cb87661a20c4abbdc3fc03",
    "url": "index.html"
  },
  {
    "revision": "f368046ed1b601b9c889",
    "url": "js/app.ba8c14ed.js"
  },
  {
    "revision": "405228a87a6f5029b8d3",
    "url": "js/chunk-vendors.0539b8cd.js"
  },
  {
    "revision": "e20299b5b672f0d66852a0eb03105ae1",
    "url": "libs/cstaticdun.min.js"
  },
  {
    "revision": "6f330093f9091406566a90b5cf269d95",
    "url": "libs/sensorsdata.min.js"
  },
  {
    "revision": "95533dbd165128645ca7665ff3c3e983",
    "url": "manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  }
]);